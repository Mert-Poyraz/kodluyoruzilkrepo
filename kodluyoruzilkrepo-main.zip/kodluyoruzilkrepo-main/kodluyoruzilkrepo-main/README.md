# Kodluyoruz Ilk Repo
This repository is the first one we created during the Kodluyoruz Front-End Education. It contains  README file and  index.html file.
## Installation
- Project clone  [MyFirstRepo](https://github.com/Mert-Poyraz/kodluyoruzilkrepo.git)
> git clone  https://github.com/Mert-Poyraz/kodluyoruzilkrepo.git

## Usage
- Open the project in Visual Studio Code.

For Linux
> cd kodluyoruzilkrepo  
code .
## Contributing
Pull requests are accepted.For big changes,please open a thread to discuss what you want to change first.


![Your Name](https://e0.pxfuel.com/wallpapers/701/179/desktop-wallpaper-your-name-your-name-anime.jpg)